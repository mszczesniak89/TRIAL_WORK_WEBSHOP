/*jshint esversion: 6 */
/*global console*/
let refURL = document.referrer;
let target = document.querySelector("#refURL");
target.href = refURL;
